package com.mulloy.belt_exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeltExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
