package com.mulloy.belt_exam.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mulloy.belt_exam.models.LoginUser;
import com.mulloy.belt_exam.models.Show;
import com.mulloy.belt_exam.models.ShowRating;
import com.mulloy.belt_exam.models.User;
import com.mulloy.belt_exam.services.AppService;



  



//.. don't forget to inlcude all your imports! ..

@Controller
public class HomeController {
 
 // Add once service is implemented:
  @Autowired
  private AppService appServ;
 
 @GetMapping("/")
 public String index(Model model) {
 
     // Bind empty User and LoginUser objects to the JSP
     // to capture the form input
     model.addAttribute("newUser", new User());
     model.addAttribute("newLogin", new LoginUser());
     return "index.jsp";
 }
 
 @PostMapping("/register")
 public String register(@Valid @ModelAttribute("newUser") User newUser, 
         BindingResult result, Model model, HttpSession session) {
     
     // TO-DO Later -- call a register method in the service
	 User user = appServ.register(newUser, result);
     // to do some extra validations and create a new user!
     
     if(result.hasErrors()) {
         // Be sure to send in the empty LoginUser before 
         // re-rendering the page.
         model.addAttribute("newLogin", new LoginUser());
         return "index.jsp";
     }
     
     // No errors! 
     // TO-DO Later: Store their ID from the DB in session, 
     // in other words, log them in.
     session.setAttribute("sessionId", user.getId());
     return "redirect:/home";
 }
 
 @PostMapping("/login")
 public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin, 
         BindingResult result, Model model, HttpSession session) {
     // Add once service is implemented:
      User user = appServ.login(newLogin, result);
     if(result.hasErrors()) {
         model.addAttribute("newUser", new User());
         return "index.jsp";
     }
 
     // No errors! 
     // TO-DO Later: Store their ID from the DB in session, 
     session.setAttribute("sessionId", user.getId());
 
     return "redirect:/home";
 }
 
 @RequestMapping("/home")
 public String home(HttpSession session, Model model) {
	 if(session.getAttribute("sessionId") == null) {
		 return "redirect:/";
	 }
	 else {
		Long userId = (Long) session.getAttribute("sessionId");
		model.addAttribute("user", this.appServ.one_user(userId));
		model.addAttribute("show_list", this.appServ.getAllShows());
		 return "home.jsp";
	 	}
	 }
 @RequestMapping("/logout")
 public String logout(HttpSession session) {
	 session.invalidate();
	 return "redirect:/";
 }
 @RequestMapping("/add/show")
 public String add_show(Model model) {
	 model.addAttribute("new_Show", new Show());
	 return "new_show.jsp";
 }
 @PostMapping("/create/show")
	public String createBook(@Valid @ModelAttribute("new_Show") Show newShow, BindingResult result, HttpSession session, Model model) {
	 	newShow.setUser(this.appServ.one_user((Long) session.getAttribute("sessionId")));
		this.appServ.create_show(newShow, result);
	 
	 	if(result.hasErrors()) {
//			model.addAttribute("new_Show", new Show());
			return "new_show.jsp";
		}
		else {
			
			return "redirect:/home";
		}
}
 @RequestMapping("/show/{show_id}")
 public String one_show(Model model, @PathVariable("show_id") Long id, HttpSession session) {
	 Show show = this.appServ.one_show(id);
	 User user = this.appServ.one_user((Long) session.getAttribute("sessionId"));
	 model.addAttribute("suser", user);
	 model.addAttribute("show", show);
	 model.addAttribute("rating", new ShowRating());
	 return "show.jsp";
 
}
 @RequestMapping("/edit/show/{show_id}")
 public String edit_book(Model model, @PathVariable("show_id") Long id) {
	 Show showToEdit = this.appServ.one_show(id);
	 model.addAttribute("showToEdit", showToEdit);
	 return "edit_show.jsp";
}
 @PutMapping("/update/show/{id}")
	public String update(@PathVariable("id") Long id, @Valid @ModelAttribute("showToEdit") Show showToEdit, BindingResult result, HttpSession session) {
		if(result.hasErrors()) {
			
			return "edit_show.jsp";
		}else { 
			showToEdit.setUser(this.appServ.one_user((Long) session.getAttribute("sessionId")));
			this.appServ.update_show(showToEdit);
			return "redirect:/home";
		}
		
	}
 @RequestMapping("/delete/show/{id}")
 	public String delete_show(@PathVariable("id")Long id) {
	 this.appServ.delete_show(id);
	 return "redirect:/home";
 }
 @PostMapping("/rate/show/{show_id}")
 	public String rate_show(@Valid @ModelAttribute("rating") ShowRating newRating, BindingResult result, HttpSession session, Model model, @PathVariable("show_id")Long show_id) {
	 Long user_id = (Long) session.getAttribute("sessionId");
	 newRating.setShow(this.appServ.one_show(show_id));
	 newRating.setUser(this.appServ.one_user(user_id));
	 System.out.println(newRating.getId());
	 if(result.hasErrors()) {
		 return "show.jsp";
	 }
	 else {
		 this.appServ.new_rating(newRating);
		 return "redirect:/home";
	 }
	 
 }
 }


