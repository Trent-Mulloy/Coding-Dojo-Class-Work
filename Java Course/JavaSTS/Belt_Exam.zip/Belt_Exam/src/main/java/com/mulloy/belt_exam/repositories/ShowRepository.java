package com.mulloy.belt_exam.repositories;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.mulloy.belt_exam.models.Show;



public interface ShowRepository extends CrudRepository<Show, Long> {
	Optional<Show> findByTitle(String title);
}
