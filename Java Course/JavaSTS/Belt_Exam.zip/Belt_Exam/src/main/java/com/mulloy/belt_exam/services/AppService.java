package com.mulloy.belt_exam.services;

import java.util.List;
import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.mulloy.belt_exam.models.LoginUser;
import com.mulloy.belt_exam.models.Show;
import com.mulloy.belt_exam.models.ShowRating;
import com.mulloy.belt_exam.models.User;
import com.mulloy.belt_exam.repositories.RatingRepository;
import com.mulloy.belt_exam.repositories.ShowRepository;
import com.mulloy.belt_exam.repositories.UserRepository;




@Service
public class AppService {
	
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private ShowRepository showRepo;
	@Autowired
	private RatingRepository ratingRepo;
	
	// TO-DO: Write register and login methods!
    public User register(User newUser, BindingResult result) {
        // TO-DO: Additional validations!
    	Optional<User> potentialUser = this.userRepo.findByEmail(newUser.getEmail());
    	if(potentialUser.isPresent()) {
    		//this means email is taken
    		result.rejectValue("email", "email taken", "This email already exists.");
    	}
    	if(!newUser.getPassword().equals(newUser.getConfirm())) {
    		result.rejectValue("confirm", "passwords dont match", "The confrim password must match the password");
    	}
    	if(result.hasErrors()) {
    		return null;
    	}
    	else {
    		String hashed = BCrypt.hashpw(newUser.getPassword(), BCrypt.gensalt());
    		newUser.setPassword(hashed);
    		return this.userRepo.save(newUser);
    		

    	}
    }
    public User login(LoginUser newLoginObject, BindingResult result) {
        // TO-DO: Additional validations!
    	System.out.println("Before");
    	Optional<User> potentialUser = this.userRepo.findByEmail(newLoginObject.getEmail());
    	System.out.println(potentialUser.isPresent());
    	if(!potentialUser.isPresent()) {
    		result.rejectValue("email", "user not found", "No User was found with this email.");
    	}
    	else {
	    	if(!BCrypt.checkpw(newLoginObject.getPassword(), potentialUser.get().getPassword())) {
	    		result.rejectValue("password", "Matches", "Invalid Password!");
	    		}
    	}
    	if(result.hasErrors()) {
    		return null;
    	}
    	else {
    		return potentialUser.get();
    	}

    }
    public User one_user(Long id) {
		return this.userRepo.findById(id).orElse(null);
	}
    
    public List<Show> getAllShows(){
    	return (List<Show>)this.showRepo.findAll();
    }
    
    public Show create_show(Show show, BindingResult result) {
    	Optional<Show> potentialShow = this.showRepo.findByTitle(show.getTitle());
    	if(potentialShow.isPresent()) {
    		result.rejectValue("title", "titleTaken", "This title already exists.");
    	}
    	if(result.hasErrors()) {
    		return null;
    	}
    	else {
    		return this.showRepo.save(show);
    	}
    	
    }
    public Show one_show(Long id) {
    	return this.showRepo.findById(id).orElse(null);
    }
    public Show update_show(Show show) {
    	return this.showRepo.save(show);
    	
    }
    public String delete_show(Long id) {
		this.showRepo.deleteById(id);
		return "Success";
	}
    
    public ShowRating new_rating(ShowRating rating) {
    	return this.ratingRepo.save(rating);
    }
    public List<ShowRating> find_ratings(Show show){
    	return this.ratingRepo.findByShow(show);
    }
}
