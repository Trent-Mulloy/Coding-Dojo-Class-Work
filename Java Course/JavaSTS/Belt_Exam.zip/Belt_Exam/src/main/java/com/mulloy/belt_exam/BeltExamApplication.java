package com.mulloy.belt_exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeltExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeltExamApplication.class, args);
	}

}
