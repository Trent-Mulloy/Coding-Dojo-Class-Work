package com.mulloy.belt_exam.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mulloy.belt_exam.models.Show;
import com.mulloy.belt_exam.models.ShowRating;

@Repository
public interface RatingRepository extends CrudRepository <ShowRating, Long> {
	List<ShowRating>findByShow(Show show);
	
}
