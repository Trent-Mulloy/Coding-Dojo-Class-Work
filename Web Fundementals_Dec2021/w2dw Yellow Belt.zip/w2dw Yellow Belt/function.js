function other (){
    document.getElementById("warn").style.display = "none"
    console.log ("hello")
}
function Cart(){
    window.alert("Your Cart Is Empty")
}
function Change1(){
    // console.log ("hello")
    document.getElementById("mainImg").src = "images/assets/cactus-s.jpg";
}
function Change2(){
    document.getElementById("mainImg").src = "images/assets/succulents-1.jpg";
}